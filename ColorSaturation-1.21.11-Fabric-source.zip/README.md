# Color Saturation — Minecraft 1.21.11 (Fabric)

A client-side starter project with a Right Shift settings screen, a 0–200% slider,
and persistent configuration at `.minecraft/config/colorsaturation.json`.

## Build
1. Install JDK 21.
2. Open this folder in IntelliJ IDEA as a Gradle project.
3. Let Gradle sync.
4. Run `gradlew build` (Windows: `gradlew.bat build`).
5. The mod jar will be in `build/libs/`.

## Important
This starter currently implements the GUI and saves the selected value. The actual
rendering/post-processing hook that changes world colors is not implemented yet.
The rendering API changed across Minecraft versions, so validate the exact 1.21.11
post-processing integration before distributing a finished jar.
