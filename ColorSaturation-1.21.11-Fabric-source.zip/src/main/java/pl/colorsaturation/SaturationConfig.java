package pl.colorsaturation;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class SaturationConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("colorsaturation.json");
    private static Data data = new Data();

    private SaturationConfig() {}

    public static float get() {
        return data.saturation;
    }

    public static void set(float value) {
        data.saturation = Math.max(0.0f, Math.min(2.0f, value));
        save();
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            Data loaded = GSON.fromJson(Files.readString(FILE), Data.class);
            if (loaded != null) data = loaded;
            data.saturation = Math.max(0.0f, Math.min(2.0f, data.saturation));
        } catch (Exception ignored) {
            data = new Data();
        }
    }

    private static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(data));
        } catch (IOException exception) {
            System.err.println("[Color Saturation] Could not save config: " + exception.getMessage());
        }
    }

    private static final class Data {
        float saturation = 1.0f;
    }
}
