package pl.colorsaturation;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class SaturationScreen extends Screen {
    private SaturationSlider slider;

    public SaturationScreen() {
        super(Text.literal("Color Saturation"));
    }

    @Override
    protected void init() {
        int centerX = width / 2;
        int centerY = height / 2;

        slider = new SaturationSlider(centerX - 100, centerY - 10, 200, 20);
        addDrawableChild(slider);

        addDrawableChild(ButtonWidget.builder(Text.literal("Reset: 100%"), button -> {
            SaturationConfig.set(1.0f);
            slider.setValue(1.0);
        }).dimensions(centerX - 100, centerY + 22, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                .dimensions(centerX - 100, centerY + 50, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 55, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Saturation: " + Math.round(SaturationConfig.get() * 100) + "%"),
                width / 2, height / 2 - 30, 0xFFFFFF);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static class SaturationSlider extends SliderWidget {
        SaturationSlider(int x, int y, int width, int height) {
            super(x, y, width, height, Text.literal("Saturation"), SaturationConfig.get() / 2.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(Math.round(value * 200) + "%"));
        }

        @Override
        protected void applyValue() {
            SaturationConfig.set((float) (value * 2.0));
        }
    }
}
