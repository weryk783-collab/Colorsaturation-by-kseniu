package pl.colorsaturation.mixin;

import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.PostEffectProcessor;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(GameRenderer.class)
public interface GameRendererMixin {
    @Accessor("postProcessor")
    PostEffectProcessor colorsaturation$getPostProcessor();
}
